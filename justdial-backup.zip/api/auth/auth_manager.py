#!/usr/bin/env python3

"""
Authentication Manager - Core Business Logic

Provides core authentication operations including:
- Password hashing and verification with salt
- JWT token creation and verification
- OTP-based email verification for signup
- Encrypted token-based password reset
- User management and database operations

All sensitive data is read from config.yaml.
No hardcoded secrets anywhere.
"""

import logging
from contextlib import contextmanager
import psycopg2
from psycopg2.extras import RealDictCursor
from typing import Optional, Dict, Any, Tuple
from datetime import datetime, timedelta, timezone
import yaml
from pathlib import Path
import os
from dotenv import load_dotenv
import re

from api.services.email_service import EmailService
from api.auth.crypto_utils import encrypt_email, decrypt_email, PasswordHasher
from api.auth.jwt_utils import JWTManager

# Load environment variables from .env file immediately
BASE_DIR = Path(__file__).resolve().parent.parent.parent
dotenv_path = BASE_DIR / '.env'
load_dotenv(dotenv_path, override=True)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ==================== AUTHENTICATION MANAGER ====================

class AuthManager:
    """Manages user authentication, registration, and password reset operations"""
    
    def __init__(self, config_path: str = "config.yaml", db_pool=None):
        """
        Initialize authentication manager
        
        Args:
            config_path: Path to configuration file
            db_pool: Optional psycopg2 SimpleConnectionPool to reuse connections
        """
        self.config = self._load_config(config_path)
        self._db_pool = db_pool
        
        # Load database configuration
        self.db_config = self.config.get('postgres', {})
        if not self.db_config:
            raise ValueError("PostgreSQL configuration not found in config.yaml")
        
        # Load security configuration
        security_config = self.config.get('security', {})
        if not security_config:
            raise ValueError("Security configuration not found in config.yaml")
        
        self.jwt_secret_key = security_config.get('jwt_secret_key')
        self.encryption_key = security_config.get('encryption_key')
        self.jwt_algorithm = security_config.get('jwt_algorithm', 'HS256')
        self.access_token_expire_minutes = int(security_config.get('access_token_expire_minutes', 1440))
        
        if not self.jwt_secret_key or not self.encryption_key:
            raise ValueError("JWT secret key and encryption key must be provided in config.yaml")
        
        # Initialize JWT manager
        self.jwt_manager = JWTManager(
            secret_key=self.jwt_secret_key,
            algorithm=self.jwt_algorithm,
            access_token_expire_minutes=self.access_token_expire_minutes
        )
        
        # Initialize password hasher
        self.password_hasher = PasswordHasher()
        
        # Load email service if configured
        self.email_service = None
        self._initialize_email_service()
        
        logger.info("✓ AuthManager initialized successfully")
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """
        Load configuration from YAML file with environment variable substitution
        """
        try:
            config_file = Path(config_path)
            if not config_file.exists():
                raise FileNotFoundError(f"Configuration file not found: {config_path}")
            
            with open(config_file, 'r') as f:
                raw_config = yaml.safe_load(f)
            
            # Substitute environment variables
            config = self._substitute_env_vars(raw_config)
            
            logger.info(f"Configuration loaded from {config_path}")
            return config
        
        except Exception as e:
            logger.error(f"Failed to load configuration: {e}", exc_info=True)
            raise
    
    @staticmethod
    def _substitute_env_vars(data):
        """
        Recursively substitute environment variables in configuration.
        """
        if isinstance(data, dict):
            return {key: AuthManager._substitute_env_vars(value) for key, value in data.items()}
        elif isinstance(data, list):
            return [AuthManager._substitute_env_vars(item) for item in data]
        elif isinstance(data, str):
            def replace_var(match):
                var_name = match.group(1)
                default_value = match.group(2)
                return os.getenv(var_name, default_value or "")
            
            return re.sub(r'\$\{([^:}]+)(?::([^}]*))?\}', replace_var, data)
        else:
            return data
    
    def _initialize_email_service(self):
        """Initialize email service if configured"""
        try:
            email_config = self.config.get('email', {})
            
            if email_config and email_config.get('host'):
                self.email_service = EmailService(email_config)
                logger.info("✓ Email service initialized")
            else:
                logger.warning("Email service not configured - emails will not be sent")
        
        except Exception as e:
            logger.warning(f"Failed to initialize email service: {e}")
            self.email_service = None
    
    def _get_db_connection(self):
        """
        Get a database connection from the pool (if available) or create a new one.
        """
        try:
            if self._db_pool:
                return self._db_pool.getconn()
            
            conn = psycopg2.connect(
                host=self.db_config.get('host'),
                port=self.db_config.get('port'),
                database=self.db_config.get('database'),
                user=self.db_config.get('user'),
                password=self.db_config.get('password')
            )
            return conn
        
        except psycopg2.Error as e:
            logger.error(f"Database connection error: {e}", exc_info=True)
            raise ValueError(f"Database connection failed: {str(e)}")
    
    def _return_db_connection(self, conn):
        """Return a connection to the pool, or close it if no pool is available."""
        try:
            if self._db_pool:
                self._db_pool.putconn(conn)
            else:
                conn.close()
        except Exception:
            pass

    @contextmanager
    def _db_connection_context(self, max_retries: int = 3):
        """
        Context manager for database connections.
        """
        import psycopg2
        last_error = None
        for attempt in range(1, max_retries + 1):
            conn = None
            try:
                conn = self._get_db_connection()

                if self._db_pool:
                    conn.poll()

                yield conn
                return  # success

            except psycopg2.OperationalError as e:
                last_error = e
                if conn is not None:
                    try:
                        if self._db_pool:
                            self._db_pool.putconn(conn, close=True)
                        else:
                            conn.close()
                    except Exception:
                        pass
                    conn = None
                logger.warning(
                    f"Stale DB connection in AuthManager attempt {attempt}/{max_retries}: {e}. "
                    + ("Retrying..." if attempt < max_retries else "No more retries.")
                )

            except Exception:
                if conn is not None:
                    try:
                        conn.rollback()
                    except Exception:
                        pass
                    self._return_db_connection(conn)
                    conn = None
                raise

            finally:
                if conn is not None:
                    self._return_db_connection(conn)

        raise last_error

    
    def generate_signup_otp(self, name: str, email: str, password: str) -> Tuple[bool, str, Optional[str]]:
        """
        Generate OTP for signup email verification
        """
        try:
            with self._db_connection_context() as conn:
                cursor = conn.cursor(cursor_factory=RealDictCursor)
                
                # Check if user already exists
                cursor.execute("SELECT user_id FROM users WHERE email = %s", (email.lower(),))
                if cursor.fetchone():
                    cursor.close()
                    logger.warning(f"[FAILED] OTP generation failed: User already exists for {email}")
                    return False, "User already exists with this email", None, 409
                
                # Hash password
                hashed_password, salt = self.password_hasher.hash_password(password)
                
                # Generate 5-digit OTP
                import secrets
                otp = ''.join([str(secrets.randbelow(10)) for _ in range(5)])
                
                # Calculate expiry (5 minutes from now)
                expires_at = datetime.now() + timedelta(minutes=5)
                
                # Store OTP in signup_otps table
                cursor.execute("""
                    INSERT INTO signup_otps (email, otp, name, password_hash, password_salt, expires_at, attempts, is_verified)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (email) DO UPDATE SET
                        otp = EXCLUDED.otp,
                        name = EXCLUDED.name,
                        password_hash = EXCLUDED.password_hash,
                        password_salt = EXCLUDED.password_salt,
                        expires_at = EXCLUDED.expires_at,
                        attempts = 0,
                        is_verified = false
                """, (email.lower(), otp, name, hashed_password, salt, expires_at, 0, False))
                
                conn.commit()
                cursor.close()
            
            # Send OTP email if email service is configured
            if self.email_service:
                try:
                    email_sent = self.email_service.send_signup_otp_email(
                        email,
                        name,
                        otp
                    )
                    if email_sent:
                        logger.info(f"✓ OTP email sent successfully to {email}")
                    else:
                        logger.warning(f"✗ Failed to send OTP email to {email}")
                except Exception as e:
                    logger.error(f"Email sending error: {e}", exc_info=True)
            
            logger.info(f"[SUCCESS] OTP generated successfully for: {email}")
            
            return True, f"OTP sent to {email}. Valid for 5 minutes.", otp, 200
        
        except psycopg2.Error as e:
            logger.error(f"Database error generating OTP: {e}", exc_info=True)
            return False, f"OTP generation failed: {str(e)}", None, 500
        except Exception as e:
            logger.error(f"Error generating OTP: {e}", exc_info=True)
            return False, f"OTP generation failed: {str(e)}", None, 500
    
    def verify_signup_otp(self, email: str, otp: str) -> Dict[str, Any]:
        """
        Verify OTP and complete user registration
        """
        try:
            with self._db_connection_context() as conn:
                cursor = conn.cursor(cursor_factory=RealDictCursor)
                
                # Get OTP record
                cursor.execute("""
                    SELECT email, otp, name, password_hash, password_salt, expires_at, attempts, is_verified
                    FROM signup_otps WHERE email = %s
                """, (email.lower(),))
                
                otp_record = cursor.fetchone()
                
                if not otp_record:
                    cursor.close()
                    logger.warning(f"[FAILED] OTP verification failed: No OTP found for {email}")
                    return {
                        'success': False,
                        'message': "No OTP found for this email",
                        'status_code': 404
                    }
                
                # Check if OTP has expired
                if datetime.now() > otp_record['expires_at']:
                    cursor.close()
                    logger.warning(f"[FAILED] OTP expired for {email}")
                    return {
                        'success': False,
                        'message': "OTP has expired",
                        'status_code': 400
                    }
                
                # Check if max attempts exceeded
                if otp_record['attempts'] >= 3:
                    cursor.close()
                    logger.warning(f"[FAILED] OTP verification failed: Max attempts exceeded for {email}")
                    return {
                        'success': False,
                        'message': "Maximum OTP verification attempts exceeded",
                        'status_code': 429
                    }
                
                # Verify OTP
                if otp_record['otp'] != otp:
                    # Increment attempts
                    cursor.execute("""
                        UPDATE signup_otps SET attempts = attempts + 1 WHERE email = %s
                    """, (email.lower(),))
                    conn.commit()
                    cursor.close()
                    logger.warning(f"[FAILED] OTP verification failed: Invalid OTP for {email}")
                    return {
                        'success': False,
                        'message': "Invalid OTP",
                        'status_code': 400
                    }
                
                # Mark as verified
                cursor.execute("""
                    UPDATE signup_otps SET is_verified = true WHERE email = %s
                """, (email.lower(),))
                
                # Create user account
                cursor.execute("""
                    INSERT INTO users (name, email, password_hash, password_salt, is_active, created_at)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    RETURNING user_id, name, email, created_at, is_active, admin_login
                """, (
                    otp_record['name'],
                    email.lower(),
                    otp_record['password_hash'],
                    otp_record['password_salt'],
                    True,
                    datetime.now()
                ))
                
                user_data = cursor.fetchone()
                
                # Fetch default Free plan limits from subscription_plans
                cursor.execute("""
                    SELECT credits_included, max_concurrency 
                    FROM subscription_plans 
                    WHERE plan_key = 'free'
                """)
                free_plan_row = cursor.fetchone()
                if free_plan_row:
                    default_credits = free_plan_row['credits_included']
                    default_concurrency = free_plan_row['max_concurrency']
                else:
                    default_credits = 1000
                    default_concurrency = 1
                
                # Assign Default "Free" Plan
                cursor.execute("""
                    INSERT INTO user_plans (user_id, plan_type, total_requests, used_requests, concurrency_limit)
                    VALUES (%s, 'free', %s, 0, %s)
                """, (user_data['user_id'], default_credits, default_concurrency))
                
                cursor.execute("""
                    INSERT INTO plan_expiry (user_id, plan_type, subscript_type, expiry_date, is_active)
                    VALUES (%s, 'free', 'MONTHLY', date_trunc('month', CURRENT_TIMESTAMP) + interval '1 month' - interval '1 second', TRUE)
                """, (user_data['user_id'],))
                
                # Delete OTP record
                cursor.execute("DELETE FROM signup_otps WHERE email = %s", (email.lower(),))
                
                conn.commit()
                cursor.close()
            
            # Create access token
            token_data = {
                "user_id": user_data['user_id'],
                "email": user_data['email']
            }
            access_token = self.jwt_manager.create_access_token(data=token_data)
            
            # Send welcome email if email service is configured
            if self.email_service:
                try:
                    self.email_service.send_welcome_email(
                        user_data['email'],
                        user_data['name']
                    )
                except Exception as e:
                    logger.warning(f"Failed to send welcome email: {e}")
            
            logger.info(f"[SUCCESS] User verified and registered successfully: {email}")
            
            return {
                'success': True,
                'message': "User registered and verified successfully",
                'access_token': access_token,
                'user': {
                    'user_id': user_data['user_id'],
                    'name': user_data['name'],
                    'email': user_data['email'],
                    'created_at': str(user_data['created_at']),
                    'is_active': user_data['is_active'],
                    'admin_login': user_data.get('admin_login', False)
                },
                'expires_in': (datetime.now(timezone.utc) + timedelta(minutes=self.access_token_expire_minutes)).isoformat().replace('+00:00', 'Z'),
                'status_code': 200
            }
        
        except psycopg2.Error as e:
            logger.error(f"Database error during OTP verification: {e}", exc_info=True)
            return {
                'success': False,
                'message': f"OTP verification failed: {str(e)}",
                'status_code': 500
            }
        except Exception as e:
            logger.error(f"Error during OTP verification: {e}", exc_info=True)
            return {
                'success': False,
                'message': f"OTP verification failed: {str(e)}",
                'status_code': 500
            }
    
    def sign_in(self, email: str, password: str) -> Dict[str, Any]:
        """
        Authenticate user with email and password
        """
        try:
            with self._db_connection_context() as conn:
                cursor = conn.cursor(cursor_factory=RealDictCursor)
                
                # Get user from database
                cursor.execute("""
                    SELECT user_id, name, email, password_hash, password_salt, is_active, created_at, admin_login
                    FROM users WHERE email = %s
                """, (email.lower(),))
                
                user = cursor.fetchone()
                
                if not user:
                    cursor.close()
                    logger.warning(f"[FAILED] Sign-in failed: User not found for {email}")
                    return {
                        'success': False,
                        'message': "Invalid email or password",
                        'status_code': 401
                    }
                
                # Verify password
                if not self.password_hasher.verify_password(
                    password, user['password_hash'], user['password_salt']
                ):
                    cursor.close()
                    logger.warning(f"[FAILED] Sign-in failed: Invalid password for {email}")
                    return {
                        'success': False,
                        'message': "Invalid email or password",
                        'status_code': 401
                    }
                
                if not user['is_active']:
                    cursor.close()
                    logger.warning(f"[FAILED] Sign-in failed: Account is not active for {email}")
                    return {
                        'success': False,
                        'message': "Account is not active",
                        'status_code': 403
                    }
                
                # Update last login
                cursor.execute("""
                    UPDATE users SET last_login = %s WHERE user_id = %s
                """, (datetime.now(), user['user_id']))
                
                conn.commit()
                cursor.close()
            
            # Create access token
            token_data = {
                "user_id": user['user_id'],
                "email": user['email']
            }
            access_token = self.jwt_manager.create_access_token(data=token_data)
            
            logger.info(f"[SUCCESS] User signed in successfully: {email}")
            
            return {
                'success': True,
                'message': "Sign-in successful",
                'access_token': access_token,
                'user': {
                    'user_id': user['user_id'],
                    'name': user['name'],
                    'email': user['email'],
                    'created_at': str(user['created_at']),
                    'is_active': user['is_active'],
                    'admin_login': user.get('admin_login', False)
                },
                'expires_in': (datetime.now(timezone.utc) + timedelta(minutes=self.access_token_expire_minutes)).isoformat().replace('+00:00', 'Z'),
                'status_code': 200
            }
        
        except psycopg2.Error as e:
            logger.error(f"Database error during sign-in: {e}", exc_info=True)
            return {
                'success': False,
                'message': f"Sign-in failed: {str(e)}",
                'status_code': 500
            }
        except Exception as e:
            logger.error(f"Error during sign-in: {e}", exc_info=True)
            return {
                'success': False,
                'message': f"Sign-in failed: {str(e)}",
                'status_code': 500
            }

    def request_password_reset(self, email: str) -> Tuple[bool, str, Optional[str], int]:
        """
        Generate a password reset token for the user
        """
        try:
            with self._db_connection_context() as conn:
                cursor = conn.cursor(cursor_factory=RealDictCursor)
                
                # Check if user exists
                cursor.execute("SELECT user_id, email, name FROM users WHERE email = %s", (email.lower(),))
                user = cursor.fetchone()
                
                cursor.close()
            
            if not user:
                logger.warning(f"[FAILED] Password reset requested for non-existent user: {email}")
                return False, "If an account exists with this email, a reset link will be sent", None, 404
            
            # Encrypt email in token
            reset_token = encrypt_email(user['email'], self.encryption_key)
            
            # Send password reset email if email service is configured
            if self.email_service:
                try:
                    email_config = self.config.get('email', {})
                    reset_url = email_config.get('reset_password_url', 'https://gcrawlai.com/auth/reset-password')
                    
                    email_sent = self.email_service.send_password_reset_email(
                        user['email'],
                        user['name'],
                        reset_url_base=reset_url,
                        encrypted_token=reset_token
                    )
                    
                    if email_sent:
                        logger.info(f"✓ Password reset email sent with encrypted token to {email}")
                    else:
                        logger.warning("Failed to send reset email")
                
                except Exception as e:
                    logger.error(f"Failed to send reset email: {e}")
            
            logger.info(f"[SUCCESS] Password reset token generated for: {email}")
            
            return True, "Password reset email sent successfully", reset_token, 200
        
        except Exception as e:
            logger.error(f"Error generating reset token: {e}", exc_info=True)
            return False, f"Error generating reset token: {str(e)}", None, 500
    
    def reset_password_with_token(self, token: str, new_password: str) -> Tuple[bool, str, int]:
        """
        Reset password using encrypted email token
        """
        try:
            # Decrypt email from token
            email = decrypt_email(token, self.encryption_key)
            
            if not email:
                logger.warning("[FAILED] Invalid or expired password reset token")
                return False, "Invalid or expired password reset token", 400
            
            # Reset password using the decrypted email
            return self._reset_password(email, new_password)
        
        except Exception as e:
            logger.error(f"Error during token-based password reset: {e}", exc_info=True)
            return False, f"Password reset failed: {str(e)}", 500
    
    def _reset_password(self, email: str, new_password: str) -> Tuple[bool, str, int]:
        """
        Reset user password (internal method)
        """
        try:
            with self._db_connection_context() as conn:
                cursor = conn.cursor(cursor_factory=RealDictCursor)
                
                # Hash new password
                hashed_password, salt = self.password_hasher.hash_password(new_password)
                
                # Update password
                cursor.execute("""
                    UPDATE users
                    SET password_hash = %s, password_salt = %s, updated_at = %s
                    WHERE email = %s
                """, (hashed_password, salt, datetime.now(), email.lower()))
                
                if cursor.rowcount == 0:
                    cursor.close()
                    logger.warning(f"[FAILED] User not found for password reset: {email}")
                    return False, "User not found", 404
                
                conn.commit()
                cursor.close()
            
            logger.info(f"[SUCCESS] Password reset successfully for: {email}")
            return True, "Password reset successfully", 200
        
        except psycopg2.Error as e:
            logger.error(f"Database error resetting password: {e}", exc_info=True)
            return False, f"Password reset failed: {str(e)}", 500
        except Exception as e:
            logger.error(f"Error resetting password: {e}", exc_info=True)
            return False, f"Password reset failed: {str(e)}", 500
    
    def verify_token(self, token: str) -> Optional[Dict[str, Any]]:
        """
        Verify JWT access token
        """
        return self.jwt_manager.verify_token(token)
    
    def get_user_by_id(self, user_id: int) -> Optional[Dict[str, Any]]:
        """
        Retrieve user information by ID
        """
        try:
            with self._db_connection_context() as conn:
                cursor = conn.cursor(cursor_factory=RealDictCursor)
                
                cursor.execute("""
                    SELECT user_id, name, email, created_at, is_active, admin_login
                    FROM users WHERE user_id = %s
                """, (user_id,))
                
                user = cursor.fetchone()
                cursor.close()
            
            if not user:
                return None
            
            return {
                'user_id': user['user_id'],
                'name': user['name'],
                'email': user['email'],
                'created_at': str(user['created_at']),
                'is_active': user['is_active'],
                'admin_login': user.get('admin_login', False)
            }
        
        except psycopg2.Error as e:
            logger.error(f"Database error retrieving user: {e}", exc_info=True)
            return None
        except Exception as e:
            logger.error(f"Error retrieving user: {e}", exc_info=True)
            return None
