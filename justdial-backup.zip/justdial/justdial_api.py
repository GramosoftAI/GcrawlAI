from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import requests

app = FastAPI()

class JustdialRequest(BaseModel):
    location: str
    category: str

@app.post("/justdial")
def scrape_justdial(req: JustdialRequest):
    """
    API endpoint that accepts a location and category, formats them into a Justdial URL,
    and sends a scraping request to the local scraper service.
    """
    url = f"https://www.justdial.com/{req.location}/{req.category}"
    
    scrape_url = "http://127.0.0.1:8000/api/v1/scrape"
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer XXXXXXXXXXXXXX"
    }
    
    payload = {
        "url": url,
        "proxy": {
            "geo": "string"
        },
        "markdown": {
            "enabled": True,
            "clean": False
        },
        "html": {
            "enabled": True,
            "clean": False,
            "remove_external_links": False,
            "relative_to_absolute_links": True,
            "remove_data_images": False,
            "ignore_tags": []
        },
        "screenshot": {
            "enabled": True,
            "full_page": False,
            "format": "png",
            "quality": 90,
            "js_render": False,
            "render_timeout": 30000,
            "auto_scroll": True,
            "scroll_delay": 500,
            "max_scrolls": 2
        },
        "seo": {
            "enabled": True
        },
        "images": {
            "enabled": True
        }
    }
    
    try:
        response = requests.post(scrape_url, json=payload, headers=headers)
        if response.status_code == 200:
            return response.json()
        else:
            raise HTTPException(status_code=response.status_code, detail=response.text)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Run with: uvicorn api:app --reload --port 8001
